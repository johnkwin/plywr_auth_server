export const DB_USER = "plywr";
export const DB_PASSWORD = "n9bT#tBAv35KwKb";
export const DB_NAME = "users";

export const TWITCH_CLIENT_ID = "cswpy9s97hrv5qtoslffl71tk7moxn";
export const TWITCH_CLIENT_SECRET = "s6tyf3ky3y8vsdf0oxhoby18kkct5x";
export const TWITCH_HANDLE = 'Player1USA';
export const TWITCH_EVENTSUB_SECRET = 'foxh4yaHeLTNE0NAO1IocDeiSg+FGmbP';

export const SALT_ROUNDS = 12;